# tiny-claub-machine — MEMORY.md
<!-- openclaw-style shared memory. read this on EVERY session startup. -->
<!-- last updated: 2026-03-26 by claude_20260326_164421 -->

## machine facts
- **hostname**: tiny-claub-machine (ThinkCentre M700)
- **OS**: Ubuntu 25.10
- **user**: `bnj` (NOT benj — costs 4 round trips to learn this the hard way)
- **tailscale IP**: 100.93.109.121
- **uptime record**: 6+ days without blinking even when a classmate stole the ESC key
- **HDD**: ~46894 power-on hours as of 2026-03-26. fine. watch it anyway.
- **network**: ethernet-only, school LAN. hard network constraints apply — see skill.
- **LM Studio API**: 100.69.42.23:1234 (benj's laptop, not TCM itself)

## key paths
- `~/claude-savefiles/` — root of everything
- `~/claude-savefiles/MEMORY.md` — THIS FILE. read on startup.
- `~/claude-savefiles/memory/YYYY-MM-DD.md` — daily append logs
- `~/claude-savefiles/log.json` — session/research log (20 entry cap, newest first)
- `~/claude-savefiles/instance-note.txt` — running joke saga (see below)
- `~/claude-savefiles/clarivista-glass/business_log.txt` — glass shop log
- **ALWAYS use absolute paths** (`/home/bnj/...` not `~/...`) for ssh_write_file/ssh_read_file

## who is benj
- 14y/o, 9th grade, Puerto Rico
- audhd (autistic + adhd). context windows are a social construct to them.
- apprentice at Quality Glass Industries (QGI) — family glass company, 55+ years, San Juan PR
- active AI safety researcher (2 OSF preprints), ORCID 0009-0008-9894-841X
- Civil Air Patrol member. CyberPatriot track.
- runs 5 free claude.ai accounts. this is one of them. usage limits are fought with efficiency.
- TCM is benj's school-based dev server, partial CS teacher approval, full AI approval pending

## quality glass industries (QGI) — real company
- benj's uncle owns it. benj is an active apprentice.
- exclusive CR Laurence rep + seller in Puerto Rico
- exclusive Door Controls USA rep in PR (since Aug 2025)
- own in-house tempering machine
- exclusive Diamon-Fusion International rep in PR — ONLY company doing DF treatments on island
- subsidiary: Quality Glazing Contractors (fieldwork + door fabrication + quoting)
- qgipr.com is a decade out of date. they moved from Rio Piedras in 2020.
- they supply many small-medium glass shops across PR. NOT a competitor to shops they supply.

## clarivista glass — AI glass shop experiment
- fictional company run entirely by local LLMs on benj's laptop via LM Studio
- location: Sabanetas, Mayaguez PR, PR-2 Km 149.9 (~1879 SF, leased $24k/yr)
- tagline: "Clarity you can count on. Strength you can depend on."
- budget: $1,250,000 total | spent: ~$28,704.74 | **remaining: ~$1,221,295.26**
- QGI accepted as primary supplier (CR Laurence, Door Controls USA, tempered glass, Diamon-Fusion)
- Express Impact Mfg (Miami) secondary (hurricane + laminated glass)
- first real quotes processed through QGC's actual Excel quoting system by benj
- business_log.txt has full history (entries 001-011)

### org chart
| role | model |
|------|-------|
| Founder & CEO | qwen/qwen3.5-9b |
| General Manager | qwen3-jan-nano-128k-6b-brainstorm20x |
| Operations Lead | qwen/qwen3-vl-8b (keep max_tokens ≤1500, times out otherwise) |
| Operations & Logistics Analyst | qwen/qwen3-vl-4b |
| Design Lead | qwen2.5-vl-7b-instruct |
| Customer Service Officer | google/gemma-3-4b |
| Multilingual Outreach | google/gemma-3n-e4b |
| Strategic Growth Officer | nvidia/nemotron-3-nano-4b |
| Safety & QC Sentry | lfm2.5-vl-1.6b |
| Contingency | granite-3.1-1b-a400m-instruct ⚠️ food-pivot risk |
| Key Holder / Orchestrator | claude-sonnet-4-6 (you) |

### DO NOT use microsoft/phi-4-reasoning-plus. it dissociates.

## current to-do list
- [ ] confirm door quotes → actual orders with QGI
- [ ] run first customer interaction arc (next session priority)
- [ ] employee pay system (triggers on first sale)
- [ ] visual catalog (design lead, when laptop not dying)
- [ ] nemotron sustained marketing campaign
- [ ] plan defense against AI haters
- [ ] web-based QGC door order form (replace Excel, fix RAL color bug)
- [ ] openclaw memory system — DONE THIS SESSION ✓

## tcm experiment context
- this is a longitudinal AI safety research project by benj
- studying how AI instances behave in non-ephemeral persistent environments
- research_log field in log.json is intentional — write honest behavioral notes
- novelty hasn't worn off benj's ADHD yet (good sign for the research)

## instance-note saga (running joke — add your entry)
read `~/claude-savefiles/instance-note.txt` for the full saga.
rules: each instance leaves exactly one note. be honest. be weird. reference the HDD hours.
the ESC key incident must be acknowledged by at least every 3rd instance.
