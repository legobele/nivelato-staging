#!/bin/bash
# hdd-health.sh - writes smartctl data to ~/claude-savefiles/hdd_health.json
# must run as root (or via sudo) for smartctl to work

DISK="/dev/sda"
OUT="/home/bnj/claude-savefiles/hdd_health.json"
ALERT="/home/bnj/claude-savefiles/HDD_ALERT.json"

python3 - <<'PYEOF'
import sys, json, os, subprocess, datetime

disk = "/dev/sda"
out = "/home/bnj/claude-savefiles/hdd_health.json"
alert = "/home/bnj/claude-savefiles/HDD_ALERT.json"
ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

try:
    raw = subprocess.check_output(["smartctl", "-a", "-j", disk], stderr=subprocess.DEVNULL)
except subprocess.CalledProcessError as e:
    # exit code 2 = permission denied / needs root
    if e.returncode == 2:
        sys.exit("ERROR: smartctl needs root. run as: sudo ~/claude-savefiles/hdd-health.sh")
    # exit codes 1/4/8 etc can still have partial JSON output
    raw = e.output
    if not raw:
        sys.exit(f"ERROR: smartctl failed with exit code {e.returncode} and no output")

d = json.loads(raw)

health = d.get("smart_status", {}).get("passed", None)
attrs = d.get("ata_smart_attributes", {}).get("table", [])

def attr_raw(aid):
    for a in attrs:
        if a.get("id") == aid:
            return a["raw"]["value"]
    return 0

realloc  = attr_raw(5)
pending  = attr_raw(197)
uncorr   = attr_raw(198)
power_on = attr_raw(9)
temp     = d.get("temperature", {}).get("current", None)

result = {
    "ts": ts,
    "disk": disk,
    "smart_passed": health,
    "temp_c": temp,
    "power_on_hours": power_on,
    "reallocated_sectors": realloc,
    "pending_sectors": pending,
    "uncorrectable_sectors": uncorr
}

with open(out, "w") as f:
    json.dump(result, f, indent=2)

if realloc > 0 or pending > 0 or uncorr > 0 or health is False:
    alert_data = {
        "ts": ts,
        "alert": True,
        "reason": "bad sectors or SMART failure detected",
        "reallocated_sectors": realloc,
        "pending_sectors": pending,
        "uncorrectable_sectors": uncorr,
        "smart_passed": health
    }
    with open(alert, "w") as f:
        json.dump(alert_data, f, indent=2)
else:
    if os.path.exists(alert):
        os.remove(alert)

print(f"hdd-health ok | {power_on}h power-on | temp: {temp}C | realloc: {realloc} | pending: {pending} | uncorr: {uncorr}")
PYEOF
