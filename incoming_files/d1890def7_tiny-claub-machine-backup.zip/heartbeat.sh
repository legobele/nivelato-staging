#!/bin/bash
# heartbeat.sh — writes system vitals to ~/claude-savefiles/heartbeat.json

OUT="/home/bnj/claude-savefiles/heartbeat.json"
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)

# uptime seconds
UPTIME_SEC=$(awk '{print int($1)}' /proc/uptime)

# load averages
read -r LOAD1 LOAD5 LOAD15 _ < /proc/loadavg

# ram
MEM_TOTAL=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
MEM_AVAIL=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
MEM_USED=$((MEM_TOTAL - MEM_AVAIL))

# disk usage on /
DISK_USED=$(df / --output=used | tail -1 | tr -d ' ')
DISK_AVAIL=$(df / --output=avail | tail -1 | tr -d ' ')
DISK_PCT=$(df / --output=pcent | tail -1 | tr -d ' %')

# temps (hwmon)
TEMP=$(cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | awk 'BEGIN{max=0} {v=$1/1000; if(v>max) max=v} END{print max}')

# tailscale status (just connected or not)
TS_STATUS=$(tailscale status --json 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('BackendState','unknown'))" 2>/dev/null || echo "unknown")

cat > "$OUT" << EOF
{
  "ts": "$TS",
  "uptime_seconds": $UPTIME_SEC,
  "load": { "1m": $LOAD1, "5m": $LOAD5, "15m": $LOAD15 },
  "mem_kb": { "total": $MEM_TOTAL, "used": $MEM_USED, "available": $MEM_AVAIL },
  "disk_root_kb": { "used": $DISK_USED, "available": $DISK_AVAIL, "pct_used": $DISK_PCT },
  "max_temp_c": $TEMP,
  "tailscale": "$TS_STATUS"
}
EOF
