@echo off
echo [powershell-http] installing dependencies...
pip install flask 2>nul || pip install flask --break-system-packages
echo.
echo [powershell-http] done. run with:
echo   python server.py
echo.
echo to set optional auth token:
echo   set PSHHTTP_TOKEN=yourtoken
echo   python server.py
echo.
echo FIREWALL NOTE:
echo   Windows Firewall will probably block port 3500 on first run.
echo   When prompted, allow access for PRIVATE networks only.
echo   Do NOT allow public networks unless you know what you're doing.
pause
