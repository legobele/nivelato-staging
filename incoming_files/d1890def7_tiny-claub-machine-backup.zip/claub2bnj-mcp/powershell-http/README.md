# powershell-http

HTTP server on port 3500. receives commands from tiny-claub-machine (via tailscale), runs them as powershell on your windows laptop, optionally with UAC elevation.

## architecture

```
claude → TCM (ssh) → curl 100.69.42.23:3500 → powershell-http → powershell (.exe)
                                                                         ↓ (if /admin)
                                                               UAC prompt on your desktop
```

## setup

1. run `setup.bat` (installs dependencies)
2. run `python server.py`
3. windows firewall will prompt on first run — allow **private networks only**
4. test from TCM: `curl http://100.69.42.23:3500/ping`

## endpoints

| method | endpoint | what it does |
|--------|----------|--------------|
| GET | /ping | health check |
| POST | /run | run powershell, no elevation |
| POST | /run/admin | run powershell WITH UAC prompt |

## request format
```json
{ "cmd": "Get-Date" }
```

## response format
```json
{
  "stdout": "Thursday, March 26, 2026 ...",
  "stderr": "",
  "exit_code": 0,
  "elevated": false,
  "timestamp": "2026-03-26T20:00:00"
}
```

## examples (from TCM)
```bash
# health check
curl http://100.69.42.23:3500/ping

# run normal powershell command
curl -X POST http://100.69.42.23:3500/run \
  -H 'Content-Type: application/json' \
  -d '{"cmd": "Get-Date"}'

# run elevated command (UAC pops on your desktop — you click yes)
curl -X POST http://100.69.42.23:3500/run/admin \
  -H 'Content-Type: application/json' \
  -d '{"cmd": "Get-LocalUser"}'
```

## optional auth token
```bash
# set before starting server
set PSHHTTP_TOKEN=yourtoken
python server.py

# then callers need:
curl -H 'Authorization: Bearer yourtoken' ...
```

## security model
- tailscale is the primary auth layer (only tailscale IPs can reach port 3500)
- do NOT open port 3500 in windows firewall for public networks
- elevated commands still require you to physically click UAC yes on your desktop
- optional PSHHTTP_TOKEN adds a second layer if you want it
- server logs every command with timestamp and caller IP to stdout

## UAC notes
- `/run/admin` triggers a real UAC dialog on your desktop
- server waits up to 30s for you to click yes (configurable via ELEVATION_TIMEOUT)
- if you don't click in time it returns a timeout error
- output is captured via temp file since elevated processes can't pipe directly
