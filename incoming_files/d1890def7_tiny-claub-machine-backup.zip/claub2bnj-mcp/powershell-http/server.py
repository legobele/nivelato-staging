#!/usr/bin/env python3
"""
powershell-http: HTTP server on port 3500
accepts POST requests from tiny-claub-machine (or anything on tailscale)
runs powershell commands, optionally with UAC elevation

endpoints:
  POST /run        - run powershell command (no elevation)
  POST /run/admin  - run powershell command WITH UAC prompt
  GET  /ping       - health check

request body (JSON):
  { "cmd": "Get-Date" }

response (JSON):
  { "stdout": "...", "stderr": "...", "exit_code": 0, "elevated": false }

SECURITY:
  - bind to 0.0.0.0 so tailscale can reach it, but only tailscale IP range
    should be allowed through windows firewall (you set that up manually)
  - no auth token by default — tailscale IS the auth layer
  - if you want a token anyway set env var PSHHTTP_TOKEN and it'll check
    Authorization: Bearer <token> on every request
  - elevated commands pop a real UAC dialog on your desktop — you must click yes
    the server waits up to 30s for you to respond before timing out

requires: pip install flask
"""

import os
import sys
import json
import subprocess
import tempfile
import time
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading

PORT = 3500
TOKEN = os.environ.get("PSHHTTP_TOKEN")  # optional bearer token
ELEVATION_TIMEOUT = 30  # seconds to wait for UAC click


def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def run_powershell(cmd: str, elevated: bool = False) -> dict:
    """
    run a powershell command.
    if elevated=True, spawns via Start-Process -Verb RunAs which triggers UAC.
    returns dict with stdout, stderr, exit_code.
    """

    if not elevated:
        # normal run — capture output directly
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True,
            text=True,
            timeout=60,
        )
        return {
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
            "exit_code": result.returncode,
            "elevated": False,
            "timestamp": datetime.now().isoformat(),
        }

    else:
        # elevated run — UAC will pop on the desktop
        # we can't capture output directly from an elevated process easily,
        # so we write output to a temp file and read it back after
        out_file = tempfile.mktemp(suffix=".txt", prefix="pshhttp_out_")
        err_file = tempfile.mktemp(suffix=".txt", prefix="pshhttp_err_")
        done_file = tempfile.mktemp(suffix=".done", prefix="pshhttp_")

        # wrap the command: run it elevated, write outputs to temp files
        # Start-Process launches the elevated powershell, -Wait blocks until done
        escaped_cmd = cmd.replace('"', '\\"').replace("'", "'")
        wrapper = (
            f"$proc = Start-Process powershell "
            f"-ArgumentList '-NoProfile','-NonInteractive','-Command',\"{escaped_cmd} | Out-File -FilePath '{out_file}' -Encoding utf8; "
            f"[System.IO.File]::WriteAllText('{done_file}', $LASTEXITCODE)\" "
            f"-Verb RunAs -Wait -PassThru; "
            f"exit $proc.ExitCode"
        )

        log(f"UAC elevation requested for: {cmd[:80]}..." if len(cmd) > 80 else f"UAC elevation requested for: {cmd}")
        log("waiting for UAC prompt to be accepted...")

        try:
            proc = subprocess.Popen(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", wrapper],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )

            # wait for done_file to appear (means elevated process finished)
            deadline = time.time() + ELEVATION_TIMEOUT
            while time.time() < deadline:
                if os.path.exists(done_file):
                    break
                time.sleep(0.5)
            else:
                proc.kill()
                return {
                    "stdout": "",
                    "stderr": f"UAC timeout: no response within {ELEVATION_TIMEOUT}s (did you click yes?)",
                    "exit_code": -1,
                    "elevated": True,
                    "timestamp": datetime.now().isoformat(),
                }

            proc.wait()

            stdout = ""
            if os.path.exists(out_file):
                with open(out_file, "r", encoding="utf-8-sig", errors="replace") as f:
                    stdout = f.read().strip()
                os.unlink(out_file)

            if os.path.exists(done_file):
                os.unlink(done_file)

            _, stderr_raw = proc.communicate() if proc.returncode is None else (b"", b"")
            stderr = stderr_raw.decode("utf-8", errors="replace").strip() if stderr_raw else ""

            return {
                "stdout": stdout,
                "stderr": stderr,
                "exit_code": proc.returncode or 0,
                "elevated": True,
                "timestamp": datetime.now().isoformat(),
            }

        except subprocess.TimeoutExpired:
            return {
                "stdout": "",
                "stderr": "command timed out (60s)",
                "exit_code": -1,
                "elevated": True,
                "timestamp": datetime.now().isoformat(),
            }
        except Exception as e:
            return {
                "stdout": "",
                "stderr": f"exception: {e}",
                "exit_code": -1,
                "elevated": True,
                "timestamp": datetime.now().isoformat(),
            }


class Handler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        log(f"{self.client_address[0]} - {format % args}")

    def send_json(self, data: dict, status: int = 200):
        body = json.dumps(data, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def check_auth(self) -> bool:
        if not TOKEN:
            return True  # no token configured, allow all
        auth = self.headers.get("Authorization", "")
        return auth == f"Bearer {TOKEN}"

    def read_body(self) -> dict | None:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None

    def do_GET(self):
        if self.path == "/ping":
            self.send_json({"status": "ok", "server": "powershell-http", "port": PORT})
        else:
            self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        if not self.check_auth():
            self.send_json({"error": "unauthorized"}, 401)
            return

        body = self.read_body()
        if body is None:
            self.send_json({"error": "invalid json body"}, 400)
            return

        cmd = body.get("cmd", "").strip()
        if not cmd:
            self.send_json({"error": "missing 'cmd' field"}, 400)
            return

        if self.path == "/run":
            log(f"run (normal): {cmd[:120]}")
            result = run_powershell(cmd, elevated=False)
            self.send_json(result)

        elif self.path == "/run/admin":
            log(f"run (ELEVATED): {cmd[:120]}")
            result = run_powershell(cmd, elevated=True)
            self.send_json(result)

        else:
            self.send_json({"error": "unknown endpoint. use /run or /run/admin"}, 404)


def main():
    log(f"powershell-http starting on port {PORT}")
    if TOKEN:
        log("auth: Bearer token required")
    else:
        log("auth: NONE (tailscale is your firewall — make sure port 3500 is NOT in your public windows firewall rules)")

    server = HTTPServer(("0.0.0.0", PORT), Handler)
    log(f"listening. ping me: curl http://<your-tailscale-ip>:{PORT}/ping")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("shutting down")
        server.shutdown()


if __name__ == "__main__":
    main()
