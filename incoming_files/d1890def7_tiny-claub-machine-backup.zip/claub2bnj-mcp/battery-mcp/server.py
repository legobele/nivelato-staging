#!/usr/bin/env python3
"""
battery-mcp: laptop charge stats MCP server
runs on benj's windows laptop, exposes battery info as MCP tools
connect via tailscale from claude or tiny-claub-machine

requires: pip install mcp psutil
"""

import json
import sys
import asyncio
from datetime import datetime

try:
    import psutil
except ImportError:
    print("ERROR: psutil not installed. run: pip install psutil", file=sys.stderr)
    sys.exit(1)

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    print("ERROR: mcp not installed. run: pip install mcp", file=sys.stderr)
    sys.exit(1)


app = Server("battery-mcp")


def get_battery_data() -> dict:
    """pull all battery stats from psutil"""
    batt = psutil.sensors_battery()
    if batt is None:
        return {"error": "no battery detected (desktop or driver issue)"}

    secs_left = batt.secsleft
    if secs_left == psutil.POWER_TIME_UNLIMITED:
        time_left = "unlimited (plugged in, full)"
    elif secs_left == psutil.POWER_TIME_UNKNOWN:
        time_left = "unknown"
    else:
        h, m = divmod(int(secs_left) // 60, 60)
        time_left = f"{h}h {m:02d}m"

    return {
        "percent": round(batt.percent, 1),
        "plugged_in": batt.power_plugged,
        "status": "charging" if batt.power_plugged else "discharging",
        "time_remaining": time_left,
        "seconds_remaining": secs_left if secs_left not in (
            psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN
        ) else None,
        "timestamp": datetime.now().isoformat(),
    }


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="get_battery",
            description="get current battery percentage, charge status, and time remaining on benj's laptop",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="get_battery_raw",
            description="get full raw battery stats as json including timestamps",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="is_plugged_in",
            description="quick boolean check: is the laptop currently plugged in?",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    data = get_battery_data()

    if "error" in data:
        return [TextContent(type="text", text=f"error: {data['error']}")]

    if name == "get_battery":
        plug_str = "plugged in" if data["plugged_in"] else "on battery"
        text = (
            f"battery: {data['percent']}% | {plug_str} | "
            f"time remaining: {data['time_remaining']}"
        )
        return [TextContent(type="text", text=text)]

    elif name == "get_battery_raw":
        return [TextContent(type="text", text=json.dumps(data, indent=2))]

    elif name == "is_plugged_in":
        return [TextContent(type="text", text=str(data["plugged_in"]).lower())]

    return [TextContent(type="text", text=f"unknown tool: {name}")]


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
