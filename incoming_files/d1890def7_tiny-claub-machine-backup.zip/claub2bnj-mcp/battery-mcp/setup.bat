@echo off
echo === battery-mcp setup ===
echo.

where python >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: python not found in PATH
    echo install python from https://python.org and make sure to check "Add to PATH"
    pause
    exit /b 1
)

python --version
echo.
echo installing dependencies...
pip install mcp psutil

echo.
echo === done! ===
echo to test, run: python server.py
echo to add to claude desktop, see claude_desktop_config.json
echo.
pause
