# battery-mcp

laptop charge stats as an MCP server. reads battery via psutil, exposes 3 tools.

## setup

1. run `setup.bat` (installs `mcp` + `psutil`)
2. merge `claude_desktop_config.json` into your actual claude desktop config at:
   `%APPDATA%\Claude\claude_desktop_config.json`
3. restart claude desktop

## tools

| tool | what it does |
|------|--------------|
| `get_battery` | percent + plugged status + time remaining (human readable) |
| `get_battery_raw` | full json dump with timestamp |
| `is_plugged_in` | returns `true` or `false` |

## example output

```
battery: 73.4% | on battery | time remaining: 2h 14m
```

## notes

- runs as stdio MCP (claude desktop launches it as a subprocess, no port needed)
- no network exposure, no firewall rules needed
- psutil reads from windows WMI battery API so it's accurate
- if `sensors_battery()` returns None you're probably on a desktop with no battery driver
