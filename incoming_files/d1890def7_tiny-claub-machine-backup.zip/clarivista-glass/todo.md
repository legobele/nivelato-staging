# Clarivista Glass — To-Do List
Last updated: 2026-03-26

## Immediate
- [ ] Confirm door quotes → actual orders with QGI
- [ ] START CUSTOMER ARC (next session)

## Operations
- [ ] Reorder architectural panels + door assemblies via QGI
- [ ] Visual catalog (qwen2.5-vl-7b when laptop can handle it)
- [ ] Nemotron sustained marketing campaign

## Finance
- [ ] Start employee pay after first sale
  - Pay structure TBD by CEO
  - Triggered on: first confirmed customer sale

## Strategy
- [ ] Plan defense against AI haters

## Tech (benj side)
- [ ] Replace QGC Excel order form with web-based system
  - Fix RAL color pricing bug from day 1

## Ongoing
- [ ] Granite food-pivot watch: ACTIVE
